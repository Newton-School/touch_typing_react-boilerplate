import React from 'react';
import "../styles/keyboard.css"
const Keyboard = ({ keysToType }) => {
    if (!Array.isArray(keysToType)) {
        return null; // or some error message
    }

    return (
        <div>
            <h2>Keyboard</h2>
            <p>Type the following keys:</p>
            <div className="keyboard">
                {keysToType.join('').split('').map((key, index) => (
                    <span key={index} className="key">
                        {key}
                    </span>
                ))}
            </div>
        </div>
    );
};

export default Keyboard;
