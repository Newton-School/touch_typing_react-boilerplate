import React, { Component } from 'react';
import '../styles/touchtyping.css';
import Keyboard from './keyboard';
import TypingBox from './typingbox';
import Results from './results';



class TouchTypingApp extends Component {
    constructor(props) {

        super(props);

        // const [count, setCount] = useState(0);
        // state variables
        this.state = {
            count: 0,
            keysToType: [],
            keysPressed: '',
            startTime: null,
            elapsedTime: 0,
            accuracy: 100,
            isPracticeStarted: false, // new state variable to check if practice has started
        };
    }

    // function to randomly generate keys
    generateRandomKeys = (length) => {
        const keys = ['a', 's', 'd', 'f', 'j', 'k', 'l', ';'];
        let randomKeys = '';
        for (let i = 0; i < length; i++) {
            const index = Math.floor(Math.random() * keys.length);
            randomKeys += keys[index];
        }
        return randomKeys;
    };

    handleKeyPress = (event) => {
        const {count, keysToType, keysPressed, startTime, isPracticeStarted } = this.state;
        const keyPressed = event.key;
        console.log(keyPressed);
        // count++;
        // console.log(count);
        if (isPracticeStarted) {
            
            // check if key pressed matches the expected key
            if (keyPressed === keysToType[0]) {
                // this.setState({
                //     count: count+1
                // });
                const newKeysToType = keysToType.slice(1); // remove the first character from keysToType
                const newKeysPressed = keysPressed + keyPressed;
                const newElapsedTime = new Date() - startTime;
                // cnt = count
                this.setState({
                    count:count+1,
                    keysToType: newKeysToType,
                    keysPressed: newKeysPressed,
                    elapsedTime: newElapsedTime,
                    accuracy: this.calculateAccuracy(count+1,newKeysPressed),
                    className: 'correct',
                });

                // if all keys have been typed, generate new keys
                if (newKeysToType.length === 0) {
                    
                    this.setState({
                        // keysToType: this.generateRandomKeys(30),
                        keysPressed: '',
                        isPracticeStarted: false
                    });
                }
            } else if (keyPressed === 'Backspace') {
                const newKeysPressed = keysPressed.slice(0, -1); // remove the last character from keysPressed
                const newKeysToType = keysToType.length === 0 ? [] : [keysToType[0], ...keysToType.slice(1)]; // add the first character back to keysToType
                this.setState({
                    keysPressed: newKeysPressed,
                    keysToType: newKeysToType,
                });
            }
            else{
                
                this.setState({
                    count: count+1,
                    accuracy: this.calculateAccuracy(count+1, keysPressed)
                })
            }
        }
    };

    // handleKeyPress = (event) => {
    //     const { keysToType, keysPressed, startTime, isPracticeStarted } = this.state;
    //     const keyPressed = event.key;
    //     console.log(keyPressed);
    //     // check if practice has started and key pressed is one of the keysToType
    //     if (isPracticeStarted && keysToType.includes(keyPressed)) {
    //         const newKeysToType = keysToType.filter((key) => key !== keyPressed);
    //         const newKeysPressed = keysPressed.concat(keyPressed);
    //         const newElapsedTime = new Date() - startTime;

    //         // update state with new values
    //         this.setState({
    //             keysToType: newKeysToType,
    //             keysPressed: newKeysPressed,
    //             elapsedTime: newElapsedTime,
    //             accuracy: this.calculateAccuracy(newKeysPressed, newKeysToType),
    //         });

    //         // if all keys have been typed, generate new keys
    //         if (newKeysToType.length === 0) {
    //             this.setState({
    //                 keysToType: this.generateRandomKeys(10),
    //                 keysPressed: '',
    //             });
    //         }
    //     }
    // };

    calculateAccuracy = (cnt, keysPressed) => {
        // const numErrors = keysPressed
        //     .split('')
        //     .filter((key, index) => key !== keysToType[index]).length;

        // return ((keysPressed.length - numErrors) / keysPressed.length) * 100;
        // return (count / keysPressed.length) * 100;
        console.log(cnt);
        if(cnt == 0)return 100;
        return ((keysPressed.length)/cnt)*100 ;

    };

    startPractice = () => {
        // generate initial keys
        const keysToType = this.generateRandomKeys(5);

        // update state to start practice
        this.setState({
            count:0,
            keysToType: keysToType.split(''),
            keysPressed: '',
            startTime: new Date(),
            elapsedTime: 0,
            accuracy: 100,
            isPracticeStarted: true,
        });
    };

    render() {
        const { keysToType, keysPressed, elapsedTime, accuracy, isPracticeStarted } = this.state;

        return (
            <div>
                <Keyboard keysToType={keysToType} />
                <TypingBox
                    keysPressed={keysPressed}
                    handleKeyPress={this.handleKeyPress}
                    startPractice={this.startPractice}
                    isPracticeStarted={isPracticeStarted}
                    keysToType={keysToType} // add the keysToType prop here
                />
                <Results elapsedTime={elapsedTime} accuracy={accuracy} />
            </div>
        );
    }
}

export default TouchTypingApp;
