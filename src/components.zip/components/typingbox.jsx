import React, { useRef } from "react";
import "../styles/typingBox.css";
const TypingBox = ({
    keysPressed,
    handleKeyPress,
    startPractice,
    isPracticeStarted,
    keysToType,
}) => {
    const typingCode = Array.isArray(keysToType) ? keysToType.join("") : "";
    const typedKeys = keysPressed.split("");

    // create a ref to the typingBox element so that we can focus on it when it's clicked
    const typingBoxRef = useRef(null);

    // function to check if a typed key matches with the expected key
    const getClassNameForIndex = (index) => {
        if (!isPracticeStarted) {
            return "";
        } else if (
            index < typedKeys.length &&
            typedKeys[index] === keysToType[index]
        ) {
            return "correct";
        } else if (index === typedKeys.length) {
            return "current";
        } else {
            return "incorrect";
        }
    };

    // focus on the typingBox element when it's clicked
    const handleTypingBoxClick = () => {
        typingBoxRef.current.focus();
    };

    return (
        <div className="typing-box" onClick={handleTypingBoxClick}>
            {/* <div className="inside-box"> */}
                <div className="typing-code">{typedKeys}</div>
                <input
                    type="text"
                    className="typing-input"
                    value={keysPressed}
                    onChange={(event) => { }}
                    onKeyDown={handleKeyPress}
                    ref={typingBoxRef}
                />
                <div className="typing-highlights">
                    {Array.isArray(keysToType) &&
                        keysToType.map((key, index) => (
                            <span key={index} className={getClassNameForIndex(index)}>
                                {key}
                            </span>
                        ))}
                </div>
            {/* </div> */}
            {/* <br> */}
            {!isPracticeStarted && (
                <button className="start-button" onClick={startPractice}>
                    Start
                </button>
            )}
            {isPracticeStarted && (
                <button className="start-button" onClick={startPractice}>
                    Restart
                </button>
            )}
            {/* </br> */}
        </div>
    );
};

export default TypingBox;
