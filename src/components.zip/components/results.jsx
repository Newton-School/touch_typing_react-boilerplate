// import React from 'react';
// import './result.css';

// const Results = ({ elapsedTime, accuracy }) => {
//     const seconds = Math.floor(elapsedTime / 1000);
//     const minutes = Math.floor(seconds / 60);
//     const remainingSeconds = seconds % 60;
//     const formattedTime = `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;

//     return (
//         <div className="results">
//             <div className="results-label">Time:</div>
//             <div className="results-value">{formattedTime}</div>
//             <div className="results-label">Accuracy:</div>
//             <div className="results-value">{accuracy.toFixed(2)}%</div>
//         </div>
//     );
// };

// export default Results;

// Results.js

import React from 'react';

const Results = ({ elapsedTime, accuracy }) => {
    const seconds = (elapsedTime / 1000).toFixed(2);

    return (
        <div>
            <h2>Results</h2>
            <p>Elapsed Time: {seconds} seconds</p>
            <p>Accuracy: {accuracy}%</p>
        </div>
    );
};

export default Results;
