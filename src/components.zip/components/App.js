import React from 'react'
import '../styles/App.css';
import TouchTypingApp from './touchtyping';


const App = () => {
    return (
        <div className="app">
            <TouchTypingApp />
        </div>
    );
};

export default App;
